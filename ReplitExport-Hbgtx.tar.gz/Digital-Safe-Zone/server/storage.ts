import { db } from "./db";
import { volunteers, type InsertVolunteer, type Volunteer } from "@shared/schema";

export interface IStorage {
  createVolunteer(volunteer: InsertVolunteer): Promise<Volunteer>;
}

export class DatabaseStorage implements IStorage {
  async createVolunteer(volunteer: InsertVolunteer): Promise<Volunteer> {
    const [newVolunteer] = await db.insert(volunteers).values(volunteer).returning();
    return newVolunteer;
  }
}

export const storage = new DatabaseStorage();
