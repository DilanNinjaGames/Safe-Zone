import React from "react";

interface PixelButtonProps extends React.ButtonHTMLAttributes<HTMLButtonElement> {
  isRed?: boolean;
}

export function PixelButton({ children, isRed = false, className = "", ...props }: PixelButtonProps) {
  return (
    <button 
      className={`${isRed ? 'pixel-btn-red' : 'pixel-btn'} ${className}`}
      {...props}
    >
      {children}
    </button>
  );
}
