import { useState, useEffect } from "react";
import { PixelButton } from "./PixelButton";

// Internal component for the Undertale-style typewriter effect
function TypewriterText({ text, onComplete }: { text: string, onComplete?: () => void }) {
  const [displayedText, setDisplayedText] = useState("");

  useEffect(() => {
    let i = 0;
    setDisplayedText("");
    
    const intervalId = setInterval(() => {
      setDisplayedText(text.substring(0, i + 1));
      i++;
      if (i >= text.length) {
        clearInterval(intervalId);
        if (onComplete) onComplete();
      }
    }, 40); // 40ms per character for classic RPG feel
    
    return () => clearInterval(intervalId);
  }, [text, onComplete]);

  return <span>{displayedText}</span>;
}

interface ChatModalProps {
  isOpen: boolean;
  onClose: () => void;
}

export function ChatModal({ isOpen, onClose }: ChatModalProps) {
  const [messages, setMessages] = useState<{sender: string, text: string}[]>([]);
  const [showInput, setShowInput] = useState(false);

  useEffect(() => {
    if (isOpen) {
      // Initial connection sequence
      setShowInput(false);
      setMessages([{ sender: "system", text: "[ CONECTANDO AL SERVIDOR SEGURO... ]" }]);
      
      const timer1 = setTimeout(() => {
        setMessages(prev => [...prev, { sender: "bot", text: "* Estás en un espacio seguro. ¿Cómo podemos ayudarte hoy?" }]);
      }, 1500);

      return () => clearTimeout(timer1);
    } else {
      // Reset state when closed
      setMessages([]);
      setShowInput(false);
    }
  }, [isOpen]);

  if (!isOpen) return null;

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center bg-black/90 backdrop-blur-sm p-4">
      {/* Modal Container */}
      <div className="w-full max-w-2xl bg-black pixel-border-red p-4 md:p-8 flex flex-col gap-6 max-h-[90vh] shadow-[0_0_50px_rgba(239,68,68,0.3)] animate-in fade-in zoom-in duration-300">
        
        {/* Header */}
        <div className="flex justify-between items-center border-b-4 border-red-600 pb-4">
          <div className="flex items-center gap-3">
            <span className="text-red-500 animate-blink">♥</span>
            <h2 className="font-pixel text-red-500 uppercase tracking-widest text-sm md:text-lg">Chat Anónimo</h2>
          </div>
          <button 
            onClick={onClose} 
            className="font-pixel text-white hover:text-red-500 text-xl transition-colors px-2 py-1 border-2 border-transparent hover:border-red-500 active:translate-y-1"
            aria-label="Cerrar modal"
          >
            X
          </button>
        </div>
        
        {/* Chat Area */}
        <div className="flex-1 overflow-y-auto space-y-6 font-vt text-2xl md:text-3xl min-h-[300px] p-2 scrollbar-thin scrollbar-thumb-white scrollbar-track-black">
          {messages.map((msg, i) => (
            <div 
              key={i} 
              className={`
                ${msg.sender === "system" ? "text-gray-500 text-center text-xl uppercase tracking-widest" : ""}
                ${msg.sender === "bot" ? "text-white" : ""}
                ${msg.sender === "user" ? "text-yellow-400 text-right" : ""}
              `}
            >
              {msg.sender === "bot" ? (
                <TypewriterText 
                  text={msg.text} 
                  onComplete={() => i === messages.length - 1 && setShowInput(true)} 
                />
              ) : (
                msg.text
              )}
            </div>
          ))}
        </div>

        {/* Input Area */}
        <div className={`flex gap-3 transition-opacity duration-500 ${showInput ? 'opacity-100' : 'opacity-0 pointer-events-none'}`}>
          <input 
            type="text" 
            placeholder="[ Escribe tu mensaje aquí... ]" 
            className="pixel-input flex-1 focus:border-white"
            disabled={!showInput}
          />
          <PixelButton disabled={!showInput}>Enviar</PixelButton>
        </div>

      </div>
    </div>
  );
}
