import React from "react";

interface PixelCardProps {
  title: string;
  children: React.ReactNode;
  isRed?: boolean;
}

export function PixelCard({ title, children, isRed = false }: PixelCardProps) {
  return (
    <div className={`p-6 md:p-8 bg-black flex flex-col gap-4 transition-transform duration-300 hover:-translate-y-2 group ${isRed ? 'pixel-border-red' : 'pixel-border'}`}>
      <h3 className="font-pixel text-lg md:text-xl text-white uppercase border-b-4 border-transparent group-hover:border-white pb-2 inline-block transition-colors self-start">
        {title}
      </h3>
      <div className="font-vt text-xl md:text-2xl text-gray-300 leading-relaxed mt-2">
        {children}
      </div>
    </div>
  );
}
