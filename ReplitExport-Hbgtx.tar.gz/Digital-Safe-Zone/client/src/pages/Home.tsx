import { useState } from "react";
import { useForm } from "react-hook-form";
import { zodResolver } from "@hookform/resolvers/zod";
import { api, type VolunteerInput } from "@shared/routes";
import { useCreateVolunteer } from "@/hooks/use-volunteers";

import { PixelCard } from "@/components/PixelCard";
import { PixelButton } from "@/components/PixelButton";
import { ChatModal } from "@/components/ChatModal";

export default function Home() {
  const [isChatOpen, setIsChatOpen] = useState(false);
  const mutation = useCreateVolunteer();
  
  const { register, handleSubmit, reset, formState: { errors } } = useForm<VolunteerInput>({
    resolver: zodResolver(api.volunteers.create.input)
  });

  const onSubmit = (data: VolunteerInput) => {
    mutation.mutate(data, {
      onSuccess: () => reset()
    });
  };

  return (
    <div className="min-h-screen bg-black text-white relative selection:bg-red-500 selection:text-white pb-32">
       
       {/* 1. Header & Nav */}
       <header className="sticky top-0 z-40 bg-black/95 backdrop-blur-sm border-b-4 border-white p-4 shadow-[0_4px_0_rgba(255,255,255,0.1)]">
         <div className="max-w-6xl mx-auto flex flex-col md:flex-row justify-between items-center gap-4">
           <div>
             <h1 className="font-pixel text-2xl md:text-3xl tracking-widest uppercase hover:scale-105 transition-transform origin-left">
               SafeZone
             </h1>
             <p className="font-vt text-gray-400 text-lg md:text-xl mt-1">
               * Tu espacio seguro en el mundo digital
             </p>
           </div>
           <nav className="flex flex-wrap justify-center gap-4 md:gap-8 font-pixel text-[10px] md:text-xs tracking-wider">
             <a href="#juego" className="hover:text-red-500 hover:-translate-y-1 transition-all uppercase">Evaluación</a>
             <a href="#info" className="hover:text-red-500 hover:-translate-y-1 transition-all uppercase">Información</a>
             <a href="#apoyo" className="hover:text-red-500 hover:-translate-y-1 transition-all uppercase">Red de Apoyo</a>
           </nav>
         </div>
       </header>
       
       <main className="max-w-6xl mx-auto px-4 md:px-8 space-y-32 py-16">
          
          {/* 2. Game Placeholder Section */}
          <section id="juego" className="scroll-mt-40">
            <h2 className="font-pixel text-xl md:text-2xl mb-8 uppercase flex items-center gap-4">
              <span className="text-red-500 animate-blink">♥</span>
              Evaluación Interactiva
            </h2>
            
            <div className="aspect-video w-full pixel-border-red bg-[#050505] flex items-center justify-center relative overflow-hidden group cursor-crosshair">
               {/* Scanline overlay effect */}
               <div className="absolute inset-0 bg-[url('data:image/svg+xml;base64,PHN2ZyB3aWR0aD0iNCIgaGVpZ2h0PSI0IiB4bWxucz0iaHR0cDovL3d3dy53My5vcmcvMjAwMC9zdmciPjxyZWN0IHdpZHRoPSI0IiBoZWlnaHQ9IjEiIGZpbGw9InJnYmEoMjU1LDI1NSwyNTUsMC4wNSkiLz48L3N2Zz4=')] opacity-50 z-0"></div>
               
               <div className="relative z-10 text-center px-4 flex flex-col items-center gap-6 group-hover:scale-110 transition-transform duration-700">
                 <p className="font-pixel text-red-500 text-sm md:text-xl leading-loose">
                   [ Área reservada para el juego HTML5 ]
                 </p>
                 <div className="font-vt text-2xl text-gray-500 animate-pulse">
                   * Presiona Z para interactuar
                 </div>
               </div>
            </div>
          </section>
          
          {/* 3. Information Section */}
          <section id="info" className="scroll-mt-40">
             <h2 className="font-pixel text-xl md:text-2xl mb-8 uppercase flex items-center gap-4">
               <span className="text-white animate-blink">♥</span>
               Tipos de Violencia
             </h2>
             
             <div className="grid grid-cols-1 lg:grid-cols-3 gap-8">
               <PixelCard title="Ciberacoso">
                 * Uso de medios digitales para acosar, intimidar o humillar a una persona. Incluye mensajes hirientes, difusión de rumores o amenazas constantes.
               </PixelCard>
               <PixelCard title="Grooming">
                 * Acciones de un adulto para ganarse la confianza de un menor en línea, con el objetivo final de obtener material explícito o encuentros.
               </PixelCard>
               <PixelCard title="Sextorsión">
                 * Forma de chantaje donde se amenaza a la víctima con publicar imágenes o videos íntimos si no cumple con exigencias económicas o sexuales.
               </PixelCard>
             </div>
          </section>
          
          {/* 4. Volunteer Form Section */}
          <section id="apoyo" className="scroll-mt-40">
            <h2 className="font-pixel text-xl md:text-2xl mb-8 uppercase flex items-center justify-center gap-4">
               <span className="text-yellow-400">★</span>
               Red de Apoyo
               <span className="text-yellow-400">★</span>
            </h2>
            
            <div className="max-w-2xl mx-auto pixel-border p-6 md:p-12 bg-[#0a0a0a] relative">
               {/* Decorative corner accents */}
               <div className="absolute top-2 left-2 w-2 h-2 bg-white"></div>
               <div className="absolute top-2 right-2 w-2 h-2 bg-white"></div>
               <div className="absolute bottom-2 left-2 w-2 h-2 bg-white"></div>
               <div className="absolute bottom-2 right-2 w-2 h-2 bg-white"></div>

               <p className="font-vt text-2xl md:text-3xl mb-10 text-center text-gray-300">
                 * Si eres profesional de la salud o quieres ser voluntario, únete a nuestra red para ayudar a quienes lo necesitan.
               </p>
               
               <form onSubmit={handleSubmit(onSubmit)} className="space-y-8">
                 <div className="space-y-2">
                   <label className="font-pixel text-xs md:text-sm text-gray-400 block uppercase">
                     Nombre
                   </label>
                   <input 
                     {...register("name")} 
                     className={`pixel-input ${errors.name ? 'border-red-500' : ''}`} 
                     placeholder="Ej: Dra. Alphys" 
                   />
                   {errors.name && (
                     <p className="text-red-500 font-vt text-xl flex items-center gap-2">
                       <span className="animate-blink">!</span> * {errors.name.message}
                     </p>
                   )}
                 </div>
                 
                 <div className="space-y-2">
                   <label className="font-pixel text-xs md:text-sm text-gray-400 block uppercase">
                     Correo Electrónico
                   </label>
                   <input 
                     type="email" 
                     {...register("email")} 
                     className={`pixel-input ${errors.email ? 'border-red-500' : ''}`} 
                     placeholder="alphys@laboratorio.com" 
                   />
                   {errors.email && (
                     <p className="text-red-500 font-vt text-xl flex items-center gap-2">
                       <span className="animate-blink">!</span> * {errors.email.message}
                     </p>
                   )}
                 </div>
                 
                 <div className="space-y-2">
                   <label className="font-pixel text-xs md:text-sm text-gray-400 block uppercase">
                     Rol en la Red
                   </label>
                   <div className="relative">
                     <select 
                       {...register("role")} 
                       className={`pixel-input appearance-none cursor-pointer ${errors.role ? 'border-red-500' : ''}`}
                     >
                       <option value="" disabled>Selecciona tu vocación...</option>
                       <option value="psychologist">Psicólogo/a</option>
                       <option value="volunteer">Voluntario/a</option>
                     </select>
                     {/* Custom dropdown arrow */}
                     <div className="absolute right-4 top-1/2 -translate-y-1/2 pointer-events-none text-white font-pixel">
                       ▼
                     </div>
                   </div>
                   {errors.role && (
                     <p className="text-red-500 font-vt text-xl flex items-center gap-2">
                       <span className="animate-blink">!</span> * Selecciona un rol válido.
                     </p>
                   )}
                 </div>
                 
                 <div className="pt-6 flex justify-end">
                   <PixelButton type="submit" disabled={mutation.isPending}>
                     {mutation.isPending ? "ENVIANDO..." : "REGISTRARSE"}
                   </PixelButton>
                 </div>
               </form>
            </div>
          </section>
       </main>
       
       {/* 5. Floating Panic Button */}
       <button 
         onClick={() => setIsChatOpen(true)}
         className="fixed bottom-6 right-6 z-40 bg-red-600 text-white border-4 border-white p-4 md:px-8 md:py-5 font-pixel text-xs md:text-sm shadow-[4px_4px_0px_0px_rgba(255,255,255,1)] hover:bg-red-500 active:translate-y-1 active:translate-x-1 active:shadow-none transition-all flex items-center justify-center gap-3 animate-bounce hover:animate-none"
         aria-label="Botón de Pánico - Hablar con alguien ahora"
       >
         <span className="text-2xl md:text-xl">🚨</span>
         <span className="hidden md:inline uppercase tracking-widest">Hablar con alguien AHORA</span>
         <span className="md:hidden uppercase tracking-widest">Ayuda</span>
       </button>
       
       {/* 6. Chat Modal Overlay */}
       <ChatModal isOpen={isChatOpen} onClose={() => setIsChatOpen(false)} />
       
    </div>
  );
}
