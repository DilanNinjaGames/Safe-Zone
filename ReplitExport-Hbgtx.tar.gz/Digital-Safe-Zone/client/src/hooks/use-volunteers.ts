import { useMutation } from "@tanstack/react-query";
import { api, type VolunteerInput } from "@shared/routes";
import { useToast } from "@/hooks/use-toast";

export function useCreateVolunteer() {
  const { toast } = useToast();
  
  return useMutation({
    mutationFn: async (data: VolunteerInput) => {
      // Validate input before sending using the shared schema
      const validated = api.volunteers.create.input.parse(data);
      
      const res = await fetch(api.volunteers.create.path, {
        method: api.volunteers.create.method,
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify(validated),
      });
      
      if (!res.ok) {
        if (res.status === 400) {
          const error = api.volunteers.create.responses[400].parse(await res.json());
          throw new Error(error.message);
        }
        throw new Error("Ocurrió un error al procesar tu solicitud.");
      }
      
      return api.volunteers.create.responses[201].parse(await res.json());
    },
    onSuccess: () => {
      toast({
        title: "¡Registro Exitoso!",
        description: "Gracias por unirte a la red de apoyo. Te contactaremos pronto.",
      });
    },
    onError: (error) => {
      toast({
        title: "Error de Registro",
        description: error.message,
        variant: "destructive",
      });
    }
  });
}
